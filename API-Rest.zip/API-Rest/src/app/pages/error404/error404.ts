import { Component } from '@angular/core';

@Component({
  selector: 'app-error404',
  imports: [],
  templateUrl: './error404.html',
  styleUrl: './error404.css',
})
export class Error404 {

}
