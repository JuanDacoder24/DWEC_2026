export interface INinjaStats {
}
