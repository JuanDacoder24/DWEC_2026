export const dato={
        
    currency: "€", 
    products: [ 
                { 
                    sku: "0K3QOSOV4V", 
                    title: "Iphone 13 Pro", 
                    price: "938.99",
                }, 
                { 
                    sku: "TGD5XORY1L", 
                    title: "Cargador", 
                    price: "49.99",
                }, 
                { 
                    sku: "IOKW9BQ9F3", 
                    title: "Funda de piel", 
                    price: "79.99",
                } 
              ] 
}

